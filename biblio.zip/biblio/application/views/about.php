<center>
<br><br>
<h2><?= $title ?></h2>
<h4>LA BIBLIOTECA ONLINE MILLENIUM PERMITE LA RESERVA DE LIBROS QUE ESTEN DISPONIBLES. ESTA BIBLIOTECA ESTA HECHA EN CODEGNITER</h4>
<img src="<?php echo base_url();?>public/images/libros/About.jpg" />
<h4>BIENVENIDO Y ESPERO QUE EL SISTEMA LES AYUDE CON SUS NECESIDADES</h4>
</p></a>

</center>
