<center>
<br><br>
<h2><?= $title ?></h2>
<h4>Bienvenidos a la Biblioteca Millenium</h4>
<img src="<?php echo base_url();?>public/images/libros/animacion.jpg" />
</center>
