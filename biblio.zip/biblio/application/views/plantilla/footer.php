<!-- Es la parte inferior de mi pagina que se va mostrar el cual va permitir tener un editor de texto para que el cliente lo pueda manejar-->
	 </div>
		 <script>
                CKEDITOR.replace( 'texto1' );
            </script>
		</body>
</html>